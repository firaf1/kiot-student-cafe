(function($) {
	"use strict";
	
	
	const ps1 = new PerfectScrollbar('.message-menu', {
	  useBothWheelAxes:true,
	  suppressScrollX:true,
	});
	
	const ps2 = new PerfectScrollbar('.notify-menu', {
	  useBothWheelAxes:true,
	  suppressScrollX:true,
	});
	
	
})(jQuery);