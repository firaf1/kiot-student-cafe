(function($) {
    "use strict";	
	$('.under-countdown').countdown100({
		endtimeYear: 0,
		endtimeMonth: 0,
		endtimeDate: 35,
		endtimeHours: 18,
		endtimeMinutes: 0,
		endtimeSeconds: 0,
		timeZone: ""
	});
	
})(jQuery);